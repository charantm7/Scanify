'use client';

// src/features/menu/components/CategoryList.tsx

import { ChefHat, Plus } from 'lucide-react';
import { EmptyState, Button } from '../../../components/ui/UiComponents';
import { CategoryBlock } from './CategoryBlock';
import { useReorderableList } from '../hooks/useReorderableList';
import type { Category, MenuItem, MenuViewMode } from '../types';

interface CategoryListProps {
  categories: Category[];
  viewMode: MenuViewMode;
  isAtCap: boolean;
  search: string;
  onRename: (id: string, name: string) => void;
  onIconChange: (id: string, icon: string) => void;
  onDelete: (id: string) => Promise<void> | void;
  onAddItem: (categoryId: string) => void;
  onEditItem: (item: MenuItem) => void;
  onDeleteItem: (id: string) => Promise<void> | void;
  onToggleItem: (item: MenuItem) => void;
  onTogglePlanHidden?: (item: MenuItem) => void;
  onReorderItems: (categoryId: string, items: MenuItem[]) => void;
  onReorderCategories: (categories: Category[]) => void;
  onCreateFirstCategory: () => void;
  isAdvanceCategory: boolean;
}

/**
 * Narrows what is on screen without rewriting the data underneath it.
 *
 * The previous version replaced `items` with the matching subset, and that
 * filtered array was then what CategoryBlock reordered and counted. Dragging
 * an item while a search was active committed the subset as the category's
 * whole list — every non-matching item vanished from the menu and had its
 * sort_order rewritten. The same filtered array also fooled the
 * "remove all items before deleting" guard into letting a full category be
 * deleted whenever the search hid its contents.
 *
 * So the category keeps its real `items`, and the ids that matched travel
 * alongside as `visibleItemIds`.
 */
type FilteredCategory = { category: Category; visibleItemIds: Set<string> | null };

function filterCategories(categories: Category[], search: string): FilteredCategory[] {
  if (!search.trim()) {
    return categories.map((category) => ({ category, visibleItemIds: null }));
  }

  const q = search.trim().toLowerCase();

  return categories
    .map((category) => {
      const nameMatches = category.name.toLowerCase().includes(q);
      const matching = category.items.filter(
        (i) => i.name.toLowerCase().includes(q) || (i.description ?? '').toLowerCase().includes(q)
      );

      return {
        category,
        // A category matched by its own name shows all of its items.
        visibleItemIds: nameMatches ? null : new Set(matching.map((i) => i.id)),
        hit: nameMatches || matching.length > 0,
      };
    })
    .filter((entry) => entry.hit)
    .map(({ category, visibleItemIds }) => ({ category, visibleItemIds }));
}

export function CategoryList({
  categories,
  viewMode,
  isAtCap,
  search,
  onRename,
  onIconChange,
  onDelete,
  onAddItem,
  onEditItem,
  onDeleteItem,
  onToggleItem,
  onTogglePlanHidden,
  onReorderItems,
  onReorderCategories,
  onCreateFirstCategory,
  isAdvanceCategory

}: CategoryListProps) {
  const visible = filterCategories(categories, search);

  const { dragIndex, overIndex, handleDragStart, handleDragOver, handleDrop, handleDragEnd } = useReorderableList(
    categories,
    onReorderCategories
  );

  if (categories.length === 0) {
    return (
      <EmptyState
        icon={ChefHat}
        title="No categories yet"
        description="Start by adding a category like 'Starters', 'Mains', or 'Drinks', then add items to it."
        action={
          <Button variant="primary" onClick={onCreateFirstCategory}>
            <Plus size={15} /> Add first category
          </Button>
        }
      />
    );
  }

  if (visible.length === 0) {
    return <p className="text-sm text-theme2 text-center py-8">No items match your search.</p>;
  }

  return (
    <div className="space-y-4">
      {visible.map(({ category, visibleItemIds }) => {
        const index = categories.findIndex((c) => c.id === category.id);
        return (
          <div
            key={category.id}
            draggable={!search}
            onDragStart={handleDragStart(index)}
            onDragOver={handleDragOver(index)}
            onDrop={handleDrop(index)}
            onDragEnd={handleDragEnd}
            style={{
              opacity: dragIndex === index ? 0.5 : 1,
              borderTop:
                overIndex === index && dragIndex !== null && dragIndex !== index ? '2px solid var(--accent)' : undefined,
            }}
          >
            <CategoryBlock
              category={category}
              visibleItemIds={visibleItemIds}
              viewMode={viewMode}
              isAtCap={isAtCap}
              onRename={onRename}
              onIconChange={onIconChange}
              onDelete={onDelete}
              onAddItem={onAddItem}
              onEditItem={onEditItem}
              onDeleteItem={onDeleteItem}
              onToggleItem={onToggleItem}
          onTogglePlanHidden={onTogglePlanHidden}
              onReorderItems={onReorderItems}
              isAdvanceCategory={isAdvanceCategory}
            />
          </div>
        );
      })}
    </div>
  );
}
