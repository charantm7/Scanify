'use client';

// src/features/menu/components/ItemRow.tsx — list-view row
// Redesigned: better spacing, mobile-friendly actions, cleaner visual hierarchy

import { useState } from 'react';
import Image from 'next/image';
import { ChefHat, Pencil, Trash2, Eye, EyeOff, Loader2, GripVertical, Lock, Unlock } from 'lucide-react';
import { DietaryDot } from './shared/DietaryDot';
import { SpiceBadge, TagBadge } from './shared/TagBadge';
import type { MenuItem } from '../types';
import { ItemImage } from './ItemCard';

interface ItemRowProps {
  item: MenuItem;
  isAdvanceCategory: boolean;
  onEdit: (item: MenuItem) => void;
  onDelete: (id: string) => Promise<void> | void;
  onToggle: (item: MenuItem) => void;
  /** Swaps which items a plan downgrade keeps out of service. */
  onTogglePlanHidden?: (item: MenuItem) => void;
}

export function ItemRow({
  item, onEdit, onDelete, onToggle, onTogglePlanHidden, isAdvanceCategory,
}: ItemRowProps) {
  const [deleting, setDeleting] = useState(false);
  const hasVariants = !!item.variants?.length;

  // Parked by a downgrade — distinct from the owner's own availability toggle,
  // so the row has to say which of the two is keeping it off the menu.
  const planHidden = Boolean(item.hidden_by_plan);
  const dimmed = !item.is_available || planHidden;

  async function handleDelete() {
    if (!confirm(`Delete "${item.name}"? This cannot be undone.`)) return;
    setDeleting(true);
    await onDelete(item.id);
    setDeleting(false);
  }

  return (
    <div
      className="
        group
        flex
        flex-col
        gap-3
        p-4
        rounded-2xl
        transition-colors
        sm:flex-row
        sm:items-center
      "
      style={{
        background: dimmed ? 'rgba(0,0,0,0.02)' : 'transparent',
      }}
    >

      <div className="flex items-center gap-3 min-w-0 flex-1">
        {/* Drag handle */}
        <GripVertical
          size={14}
          className="
            hidden
            sm:block
            md:block
            flex-shrink-0
            cursor-grab
            select-none
            opacity-0
            group-hover:opacity-40
            transition
          "
          style={{ color: 'var(--text2)' }}
        />

        {/* Thumbnail */}
        <div
          className="
          w-16
          h-16
          rounded-xl
          overflow-hidden
          flex
          items-center
          justify-center
          flex-shrink-0
        "
          style={{
            background: 'var(--accentlt)',
            opacity: dimmed ? 0.5 : 1,
          }}
        >
          {item.image_url ? (
            <ItemImage item={item} variant={'list'} />
          ) : (
            <ChefHat size={16} style={{ color: 'var(--accent)' }} />
          )}
        </div>

        {/* Info */}
        <div
          className="flex-1 min-w-0 space-y-2.5"
          style={{ opacity: dimmed ? 0.55 : 1 }}
        >
          <div className="flex items-center gap-2 flex-wrap">
            {item.dietary_type && <DietaryDot type={item.dietary_type} />}
            <span
              className="text-sm font-semibold truncate"
              style={{ color: 'var(--text)' }}
            >
              {item.name}
            </span>
            {!item.is_available && (
              <span
                className="inline-flex  items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wide"
                style={{ background: 'var(--border)', color: 'var(--text2)' }}
              >
                Hidden
              </span>
            )}
            {planHidden && (
              <span
                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wide"
                style={{ background: 'var(--accentlt)', color: 'var(--accent)' }}
                title="Over your plan's item limit, so it is not shown to diners"
              >
                <Lock size={9} /> Over plan limit
              </span>
            )}
          </div>

          {item.description && (
            <p
              className="text-xs mt-0.5 truncate"
              style={{ color: 'var(--text2)', maxWidth: '90%' }}
            >
              {item.description}
            </p>
          )}

          {isAdvanceCategory && (
            <>
              {(item.tags?.length ?? 0) > 0 && (
                <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                  {item.tags!.map((tag) => (
                    <TagBadge key={tag} tag={tag} />
                  ))}
                </div>
              )}

              {item.spice_level && (
                <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                  <SpiceBadge tag={item.spice_level} />
                </div>
              )}
            </>
          )}


        </div>

      </div>

      <div
        className="
        flex
        items-center
        justify-between
        sm:justify-end
        gap-4
      "
      >

        <div
          className="text-right"
          style={{ opacity: dimmed ? 0.5 : 1 }}
        >
          <p
            className="text-sm font-bold"
            style={{
              color: 'var(--text)',
              fontVariantNumeric:
                'tabular-nums',
            }}
          >
            ₹{Number(item.price).toFixed(2)}
          </p>

          {hasVariants && (
            <p
              className="text-[10px]"
              style={{
                color: 'var(--text2)',
              }}
            >
              +{item.variants.length} sizes
            </p>
          )}
        </div>

        {/* Actions — always visible on mobile, hover-reveal on desktop */}
        <div className="flex items-center gap-1 flex-shrink-0 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
          {onTogglePlanHidden && (
            <button
              onClick={() => onTogglePlanHidden(item)}
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-all"
              style={{ color: planHidden ? 'var(--accent)' : 'var(--text2)' }}
              title={
                planHidden
                  ? 'Bring back within your plan limit (hide another item first if full)'
                  : "Hide to make room for another item within your plan's limit"
              }
              aria-label={planHidden ? 'Restore item within plan limit' : 'Hide item to free a plan slot'}
            >
              {planHidden ? <Unlock size={13} /> : <Lock size={13} />}
            </button>
          )}

          <button
            onClick={() => onToggle(item)}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all"
            style={{ color: 'var(--text2)' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'var(--accentlt)';
              e.currentTarget.style.color = 'var(--accent)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = 'var(--text2)';
            }}
            title={item.is_available ? 'Hide from menu' : 'Show on menu'}
          >
            {item.is_available ? <Eye size={13} /> : <EyeOff size={13} />}
          </button>

          <button
            onClick={() => onEdit(item)}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all"
            style={{ color: 'var(--text2)' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'var(--accentlt)';
              e.currentTarget.style.color = 'var(--accent)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = 'var(--text2)';
            }}
            title="Edit item"
          >
            <Pencil size={13} />
          </button>

          <button
            onClick={handleDelete}
            disabled={deleting}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-all disabled:opacity-50"
            style={{ color: '#ef4444' }}
            onMouseEnter={(e) => (e.currentTarget.style.background = '#fef2f2')}
            onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
            title="Delete item"
          >
            {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
          </button>
        </div>

      </div>
    </div>
  );
}