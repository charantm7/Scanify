// features/menu/components/ItemBadges.tsx
"use client";

import { Flame } from "lucide-react";
import { DIETARY_CONFIG, SPICE_CONFIG } from "../constant";
import type { DietaryFlag, MenuItem, SpiceLevel } from "../types";

// ── Dietary dot indicator (Indian standard) ───────────────────────────────────
export function DietaryIndicator({ flag }: { flag: DietaryFlag | null }) {
    if (!flag) return null;
    const cfg = DIETARY_CONFIG[flag];

    return (
        <div
            className="w-[14px] h-[14px] rounded-[3px] border-[1.5px] flex items-center justify-center flex-shrink-0"
            style={{ borderColor: cfg.ring }}
            title={cfg.label}
            aria-label={cfg.label}
        >
            <div
                className="w-[6px] h-[6px] rounded-full"
                style={{ background: cfg.dot }}
            />
        </div>
    );
}

// ── Spice level indicator ──────────────────────────────────────────────────────
export function SpiceIndicator({ level }: { level: SpiceLevel }) {
    const cfg = SPICE_CONFIG[level];
    if (cfg.peppers === 0) return null;

    return (
        <div
            className="flex items-center gap-0.5"
            title={cfg.label}
            aria-label={`Spice level: ${cfg.label}`}
        >
            {Array.from({ length: cfg.peppers }).map((_, i) => (
                <Flame
                    key={i}
                    size={10}
                    style={{ color: cfg.color }}
                    fill={cfg.color}
                />
            ))}
        </div>
    );
}

// ── System badges (Bestseller, New, etc.) ────────────────────────────────────
type SystemBadgeKey = keyof typeof SYSTEM_BADGES;

export function SystemBadge({ badgeKey }: { badgeKey: SystemBadgeKey }) {
    const cfg = SYSTEM_BADGES[badgeKey];
    return (
        <span
            className="text-[9px] font-bold px-1.5 py-0.5 rounded-full leading-none tracking-wide uppercase"
            style={{ color: cfg.color, background: cfg.bg }}
        >
            {cfg.label}
        </span>
    );
}

// ── Composed: all badges for one item ────────────────────────────────────────
export function ItemBadgeRow({ item }: { item: MenuItem }) {
    const systemKeys: SystemBadgeKey[] = [
        "is_bestseller",
        "is_new",
        "is_featured",
        "is_chef_special",
    ];

    const activeBadges = systemKeys.filter((k) => item[k]);

    if (activeBadges.length === 0) return null;

    return (
        <div className="flex items-center gap-1 flex-wrap">
            {activeBadges.map((k) => (
                <SystemBadge key={k} badgeKey={k} />
            ))}
        </div>
    );
}