import SkeletonBlock from "../../../components/layouts/SkeletonBlock";

export default function AnalyticsSkeletonBlock() {
    return (
        <div className="space-y-5">


            <div className="flex items-center justify-between">
                <SkeletonBlock
                    h="h-8"
                    w="w-40"
                />

                <SkeletonBlock
                    h="h-8"
                    w="w-24"
                />
            </div>


            <div className="grid gap-4 sm:grid-cols-3">
                <SkeletonBlock h="h-24" />
                <SkeletonBlock h="h-24" />
                <SkeletonBlock h="h-14" />
            </div>



            <SkeletonBlock h="h-64" />
        </div>
    );
}