'use client';

import { useCallback, useEffect, useState } from 'react';
import { useApp } from '../../../context/AppContext';
import type { MenuScanRow } from '../../../types/supabase';
import { getMenuScans, getPrevMenuScan, MenuScansWithItem } from '../queries/analytics.query';
import { AnalyticsPeriod } from '../constants';

import {
    AnalyticsStats,
    AdvancedAnalyticsStats,
    BasicAnalyticsStats,
} from '../types';

import {
    periodToDays,
    sinceDate,
    buildComparison,
    buildDayStats,
    buildFunnel,
    buildPeakDays,
    buildPeakHours,
    buildQrBreakdown,
    buildTopItems,
    isAdvancedStats
} from '../services/analytics.service';




// Hook
export function useAnalytics(period: AnalyticsPeriod = '7d') {
    const {
        hotel,
        supabase,
        canViewBasicAnalytics,
        canViewAdvancedAnalytics,
    } = useApp();

    const [stats, setStats] = useState<AnalyticsStats | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const hotelId = hotel?.id;
    const fetchAll = useCallback(async () => {
        if (!hotelId || !canViewBasicAnalytics) {
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        const days = periodToDays(period);
        const since = sinceDate(days);

        // double the period selected
        const prevSince = sinceDate(days * 2);

        try {

            // current scans
            const scans = await getMenuScans(supabase, hotelId, since);

            const currentScans: MenuScansWithItem[] = scans ?? [];

            // Basic plan analytics
            const basicStats: BasicAnalyticsStats = {
                totalScans: currentScans.filter(s => s.event_type === 'qr_scan').length,
                totalMenuViews: currentScans.filter(s => s.event_type === 'page_view').length,
                totalItemViews: currentScans.filter(s => s.event_type === 'item_modal_open').length,
                uniqueDays: new Set(currentScans.map(s => s.scanned_at.slice(0, 10))).size,
                scansByDay: buildDayStats(currentScans, days),
                topItems: buildTopItems(currentScans),
            };


            if (!canViewAdvancedAnalytics) {
                setStats(basicStats);
                return;
            }

            const prevRes = await getPrevMenuScan(supabase, hotelId, prevSince, since);
            const previousScans: MenuScansWithItem[] = prevRes as MenuScansWithItem[];

            // Repeat-day: days with ≥ 2 qr_scan events (proxy for return traffic)
            const scansByDate = new Map<string, number>();
            for (const s of currentScans) {
                if (s.event_type !== 'qr_scan') continue;
                const k = s.scanned_at.slice(0, 10);
                scansByDate.set(k, (scansByDate.get(k) ?? 0) + 1);
            }
            const repeatDays = [...scansByDate.values()].filter(v => v >= 2).length;

            // Avg session depth: item_views per qr_scan
            const qrCount = basicStats.totalScans || 1;
            const avgSessionDepth = Math.round((basicStats.totalItemViews / qrCount) * 10) / 10;

            const advancedStats: AdvancedAnalyticsStats = {
                ...basicStats,
                topItems: buildTopItems(currentScans),
                peakHours: buildPeakHours(currentScans),
                peakDays: buildPeakDays(currentScans),
                qrBreakdown: buildQrBreakdown(currentScans),
                funnel: buildFunnel(currentScans),
                comparison: buildComparison(currentScans, previousScans),
                repeatDays,
                avgSessionDepth,
            };

            setStats(advancedStats);
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setLoading(false);
        }
    }, [hotelId, period, canViewBasicAnalytics, canViewAdvancedAnalytics, supabase]);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        fetchAll();
    }, [fetchAll]);


    return {
        stats,
        loading,
        error,
        canViewBasicAnalytics,
        canViewAdvancedAnalytics,
        refetch: fetchAll,
    };
}