'use client';

// src/features/menu/components/InlineEdit.tsx

import { useEffect, useRef, useState } from 'react';

interface InlineEditProps {
  value: string;
  onSave: (value: string) => void;
  placeholder?: string;
}

export function InlineEdit({ value, onSave, placeholder = 'Enter name…' }: InlineEditProps) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  function commit() {
    const trimmed = val.trim();
    if (!trimmed) {
      setVal(value);
      setEditing(false);
      return;
    }
    if (trimmed !== value) onSave(trimmed);
    setEditing(false);
  }

  if (editing) {
    return (
      <input
        ref={inputRef}
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === 'Enter') commit();
          if (e.key === 'Escape') {
            setVal(value);
            setEditing(false);
          }
        }}
        className="font-semibold text-sm text-theme bg-transparent border-b-2 outline-none w-48"
        style={{ borderColor: 'var(--accent)' }}
      />
    );
  }

  return (
    <span
      onClick={() => {
        setVal(value);
        setEditing(true);
      }}
      className="font-semibold text-sm text-theme cursor-text hover:underline"
      title="Click to rename"
    >
      {value || placeholder}
    </span>
  );
}
