'use client';

// src/features/menu/components/ItemCard.tsx — grid-view card

import { useState } from 'react';
import Image from 'next/image';
import { ChefHat, Pencil, Trash2, Eye, EyeOff, Loader2 } from 'lucide-react';
import { Badge } from '../../../components/shared/ui';
import { DietaryDot } from './shared/DietaryDot';
import { TagBadge } from './shared/TagBadge';
import type { MenuItem } from '../types';

interface ItemCardProps {
  item: MenuItem;
  onEdit: (item: MenuItem) => void;
  onDelete: (id: string) => Promise<void> | void;
  onToggle: (item: MenuItem) => void;
}

export function ItemCard({ item, onEdit, onDelete, onToggle }: ItemCardProps) {
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    if (!confirm(`Delete "${item.name}"? This cannot be undone.`)) return;
    setDeleting(true);
    await onDelete(item.id);
    setDeleting(false);
  }

  return (
    <div
      className="rounded-xl border overflow-hidden flex flex-col group"
      style={{ borderColor: 'var(--border)', background: 'var(--card)', opacity: item.is_available ? 1 : 0.6 }}
    >
      <div className="relative h-28 flex items-center justify-center" style={{ background: 'var(--accentlt)' }}>
        {item.image_url ? (
          <Image
            src={item.image_url}
            alt={item.name}
            fill
            className="object-cover"
            onError={(e: React.SyntheticEvent<HTMLImageElement>) => {
              e.currentTarget.style.display = 'none';
            }}
          />
        ) : (
          <ChefHat size={24} style={{ color: 'var(--accent)' }} />
        )}
        {!item.is_available && (
          <div className="absolute top-2 left-2">
            <Badge variant="neutral">Hidden</Badge>
          </div>
        )}
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onToggle(item)}
            className="w-7 h-7 rounded-lg flex items-center justify-center bg-card text-theme2 hover:text-theme transition shadow"
            title="Toggle visibility"
          >
            {item.is_available ? <Eye size={13} /> : <EyeOff size={13} />}
          </button>
        </div>
      </div>

      <div className="p-3 flex-1 flex flex-col gap-1.5">
        <div className="flex items-center gap-1.5">
          {item.dietary_type && <DietaryDot type={item.dietary_type} />}
          <p className="text-sm font-semibold text-theme truncate flex-1">{item.name}</p>
        </div>
        {item.description && <p className="text-xs text-theme2 line-clamp-2">{item.description}</p>}
        {(item.tags?.length ?? 0) > 0 && (
          <div className="flex items-center gap-1 flex-wrap">
            {item.tags!.map((tag) => (
              <TagBadge key={tag} tag={tag} />
            ))}
          </div>
        )}
        <div className="mt-auto pt-2 flex items-center justify-between">
          <span className="text-sm font-bold text-theme">
            ₹{Number(item.price).toFixed(2)}
            {item.variants?.length ? ` +${item.variants.length}` : ''}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onEdit(item)}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-theme2 hover:bg-theme3 transition"
              title="Edit item"
            >
              <Pencil size={13} />
            </button>
            <button
              onClick={handleDelete}
              disabled={deleting}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 transition"
              title="Delete item"
            >
              {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
