'use client';

// src/features/menu/components/UpgradeAlerts.tsx

import { Zap } from 'lucide-react';
import { Alert } from '../../../components/shared/ui';

interface UpgradeAlertsProps {
  isTrialExpired: boolean;
  isAtMenuLimit: boolean;
  isTrialing: boolean;
  maxMenuItems: number;
  onUpgrade: () => void;
}

export function UpgradeAlerts({ isTrialExpired, isAtMenuLimit, isTrialing, maxMenuItems, onUpgrade }: UpgradeAlertsProps) {
  return (
    <>
      {isTrialExpired && (
        <Alert
          type="info"
          title="Free Trial Ended"
          message="Your trial has ended. Upgrade to continue managing your menu and unlock all features."
          action={
            <button
              onClick={onUpgrade}
              className="flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg text-white text-xs font-bold"
              style={{ background: 'var(--accent)' }}
            >
              <Zap size={12} /> Upgrade
            </button>
          }
        />
      )}
      {isAtMenuLimit && (
        <Alert
          type="warning"
          title={`Item limit reached (${maxMenuItems}/${maxMenuItems} on ${isTrialing ? 'Trial' : 'Free'} plan)`}
          message="Upgrade to Starter or Pro to add unlimited items."
          action={
            <button onClick={onUpgrade} className="flex-shrink-0 flex items-center gap-1 text-xs font-bold" style={{ color: 'var(--accent)' }}>
              <Zap size={12} /> Upgrade
            </button>
          }
        />
      )}
    </>
  );
}
