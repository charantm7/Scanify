'use client';

// src/features/menu/components/ItemRow.tsx — list-view row

import { useState } from 'react';
import Image from 'next/image';
import { ChefHat, Pencil, Trash2, Eye, EyeOff, Loader2, GripVertical } from 'lucide-react';
import { Badge } from '../../../components/shared/ui';
import { DietaryDot } from './shared/DietaryDot';
import { TagBadge } from './shared/TagBadge';
import type { MenuItem } from '../types';

interface ItemRowProps {
  item: MenuItem;
  onEdit: (item: MenuItem) => void;
  onDelete: (id: string) => Promise<void> | void;
  onToggle: (item: MenuItem) => void;
}

export function ItemRow({ item, onEdit, onDelete, onToggle }: ItemRowProps) {
  const [deleting, setDeleting] = useState(false);
  const hasVariants = !!item.variants?.length;

  async function handleDelete() {
    if (!confirm(`Delete "${item.name}"? This cannot be undone.`)) return;
    setDeleting(true);
    await onDelete(item.id);
    setDeleting(false);
  }

  return (
    <div
      className="flex items-center gap-3 px-4 py-3 border-b last:border-b-0 hover:bg-theme3 transition-colors group"
      style={{ borderColor: 'var(--border)' }}
    >
      <GripVertical size={14} className="text-theme2 opacity-0 group-hover:opacity-100 flex-shrink-0 cursor-grab" />

      <div
        className="w-10 h-10 rounded-lg flex-shrink-0 overflow-hidden flex items-center justify-center"
        style={{ background: 'var(--accentlt)' }}
      >
        {item.image_url ? (
          <Image
            src={item.image_url}
            alt={item.name}
            height={40}
            width={40}
            className="object-cover w-full h-full"
            onError={(e: React.SyntheticEvent<HTMLImageElement>) => {
              e.currentTarget.style.display = 'none';
            }}
          />
        ) : (
          <ChefHat size={16} style={{ color: 'var(--accent)' }} />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          {item.dietary_type && <DietaryDot type={item.dietary_type} />}
          <p className="text-sm font-semibold text-theme truncate">{item.name}</p>
          {!item.is_available && <Badge variant="neutral">Hidden</Badge>}
        </div>
        {item.description && <p className="text-xs text-theme2 truncate">{item.description}</p>}
        {(item.tags?.length ?? 0) > 0 && (
          <div className="flex items-center gap-1 mt-1 flex-wrap">
            {item.tags!.map((tag) => (
              <TagBadge key={tag} tag={tag} />
            ))}
          </div>
        )}
      </div>

      <div className="text-right flex-shrink-0">
        <span className="text-sm font-bold text-theme block">₹{Number(item.price).toFixed(2)}</span>
        {hasVariants && <span className="text-[10px] text-theme2">+{item.variants!.length} sizes</span>}
      </div>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => onToggle(item)}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-theme2 hover:bg-theme3 transition"
          title={item.is_available ? 'Hide item' : 'Show item'}
        >
          {item.is_available ? <Eye size={13} /> : <EyeOff size={13} />}
        </button>
        <button
          onClick={() => onEdit(item)}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-theme2 hover:bg-theme3 transition"
          title="Edit item"
        >
          <Pencil size={13} />
        </button>
        <button
          onClick={handleDelete}
          disabled={deleting}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 transition"
          title="Delete item"
        >
          {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
        </button>
      </div>
    </div>
  );
}
