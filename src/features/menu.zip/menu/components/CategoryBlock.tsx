'use client';

// src/features/menu/components/CategoryBlock.tsx

import { useState } from 'react';
import { Plus, Trash2, Loader2, ChevronDown, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';
import { Button, Badge } from '../../../components/shared/ui';
import { InlineEdit } from './InlineEdit';
import { IconPicker } from './shared/IconPicker';
import { ItemRow } from './ItemRow';
import { ItemCard } from './ItemCard';
import { useReorderableList } from '../hooks/useReorderableList';
import type { Category, MenuItem, MenuViewMode } from '../types';

interface CategoryBlockProps {
  category: Category;
  viewMode: MenuViewMode;
  isAtCap: boolean;
  onRename: (id: string, name: string) => void;
  onIconChange: (id: string, icon: string) => void;
  onDelete: (id: string) => Promise<void> | void;
  onAddItem: (categoryId: string) => void;
  onEditItem: (item: MenuItem) => void;
  onDeleteItem: (id: string) => Promise<void> | void;
  onToggleItem: (item: MenuItem) => void;
  onReorderItems: (categoryId: string, items: MenuItem[]) => void;
}

export function CategoryBlock({
  category,
  viewMode,
  isAtCap,
  onRename,
  onIconChange,
  onDelete,
  onAddItem,
  onEditItem,
  onDeleteItem,
  onToggleItem,
  onReorderItems,
}: CategoryBlockProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const items = category.items;

  const { dragIndex, overIndex, handleDragStart, handleDragOver, handleDrop, handleDragEnd } = useReorderableList(
    items,
    (reordered) => onReorderItems(category.id, reordered)
  );

  async function handleDelete() {
    if (items.length > 0) {
      toast.error('Remove all items before deleting this category');
      return;
    }
    if (!confirm(`Delete category "${category.name}"?`)) return;
    setDeleting(true);
    await onDelete(category.id);
    setDeleting(false);
  }

  return (
    <div className="rounded-2xl border overflow-hidden" style={{ borderColor: 'var(--border)', background: 'var(--card)' }}>
      <div
        className="flex items-center gap-3 px-4 py-3 border-b"
        style={{ borderColor: 'var(--border)', background: 'var(--accentlt)' }}
      >
        <button onClick={() => setCollapsed((c) => !c)} className="flex-shrink-0">
          {collapsed ? (
            <ChevronRight size={15} style={{ color: 'var(--accent)' }} />
          ) : (
            <ChevronDown size={15} style={{ color: 'var(--accent)' }} />
          )}
        </button>
        <IconPicker value={category.icon} onChange={(icon) => onIconChange(category.id, icon)} />
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <InlineEdit value={category.name} onSave={(name) => onRename(category.id, name)} />
          <Badge variant="default">{items.length}</Badge>
        </div>
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => !isAtCap && onAddItem(category.id)}
            disabled={isAtCap}
            title={isAtCap ? 'Menu item limit reached' : 'Add item'}
          >
            <Plus size={13} /> Add item
          </Button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 transition disabled:opacity-50"
          >
            {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
          </button>
        </div>
      </div>

      {!collapsed &&
        (items.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-sm text-theme2">No items yet.</p>
            {!isAtCap && (
              <button
                onClick={() => onAddItem(category.id)}
                className="mt-2 text-sm font-semibold underline"
                style={{ color: 'var(--accent)' }}
              >
                Add your first item
              </button>
            )}
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-3">
            {items.map((item) => (
              <ItemCard key={item.id} item={item} onEdit={onEditItem} onDelete={onDeleteItem} onToggle={onToggleItem} />
            ))}
          </div>
        ) : (
          <div>
            {items.map((item, index) => (
              <div
                key={item.id}
                draggable
                onDragStart={handleDragStart(index)}
                onDragOver={handleDragOver(index)}
                onDrop={handleDrop(index)}
                onDragEnd={handleDragEnd}
                style={{
                  opacity: dragIndex === index ? 0.4 : 1,
                  borderTop:
                    overIndex === index && dragIndex !== null && dragIndex !== index
                      ? '2px solid var(--accent)'
                      : undefined,
                }}
              >
                <ItemRow item={item} onEdit={onEditItem} onDelete={onDeleteItem} onToggle={onToggleItem} />
              </div>
            ))}
          </div>
        ))}
    </div>
  );
}
