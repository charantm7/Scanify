'use client';

// src/features/menu/components/CategoryCreateBar.tsx

import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../../../components/shared/ui';
import { IconPicker } from './shared/IconPicker';

interface CategoryCreateBarProps {
  disabled?: boolean;
  loading?: boolean;
  onCreate: (name: string, icon: string | null) => void;
}

export function CategoryCreateBar({ disabled, loading, onCreate }: CategoryCreateBarProps) {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState<string | null>(null);

  function submit() {
    const trimmed = name.trim();
    if (!trimmed) return;
    onCreate(trimmed, icon);
    setName('');
    setIcon(null);
  }

  return (
    <div className="flex gap-2 items-center">
      <IconPicker value={icon} onChange={setIcon} />
      <input
        placeholder="New category name (e.g. Starters, Mains, Desserts)"
        value={name}
        onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && submit()}
        className="flex-1 px-4 py-2.5 rounded-xl border bg-card text-theme text-sm placeholder:text-theme2 outline-none focus:ring-2 focus:ring-[var(--accent)]/30 transition"
        style={{ borderColor: 'var(--border)' }}
        disabled={disabled}
      />
      <Button variant="primary" disabled={disabled} loading={loading} onClick={submit}>
        <Plus size={15} /> <span className="hidden md:inline">Add Category</span>
      </Button>
    </div>
  );
}
