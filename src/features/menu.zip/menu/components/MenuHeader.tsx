'use client';

// src/features/menu/components/MenuHeader.tsx
//
// Title row + plan-usage ring + search + list/grid toggle.

import { Search, LayoutGrid, List } from 'lucide-react';
import type { MenuViewMode } from '../types';

interface MenuHeaderProps {
  totalItems: number;
  maxMenuItems: number;
  planLabel: string;
  search: string;
  onSearchChange: (value: string) => void;
  viewMode: MenuViewMode;
  onViewModeChange: (mode: MenuViewMode) => void;
}

function UsageRing({ used, max }: { used: number; max: number }) {
  const unlimited = max === -1;
  const pct = unlimited ? 0 : Math.min(100, (used / Math.max(max, 1)) * 100);
  const radius = 16;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="relative w-10 h-10 flex-shrink-0">
      <svg width="40" height="40" viewBox="0 0 40 40" className="-rotate-90">
        <circle cx="20" cy="20" r={radius} fill="none" stroke="var(--accentlt)" strokeWidth="4" />
        {!unlimited && (
          <circle
            cx="20"
            cy="20"
            r={radius}
            fill="none"
            stroke="var(--accent)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
          />
        )}
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold" style={{ color: 'var(--accent)' }}>
        {unlimited ? '∞' : `${Math.round(pct)}%`}
      </span>
    </div>
  );
}

export function MenuHeader({
  totalItems,
  maxMenuItems,
  planLabel,
  search,
  onSearchChange,
  viewMode,
  onViewModeChange,
}: MenuHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <UsageRing used={totalItems} max={maxMenuItems} />
        <div>
          <h1 className="font-syne font-bold text-2xl text-theme">Menu Builder</h1>
          <p className="text-sm text-theme2 mt-0.5">
            {totalItems} item{totalItems !== 1 ? 's' : ''} · {planLabel} plan: {totalItems} /{' '}
            {maxMenuItems === -1 ? '∞' : maxMenuItems}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 sm:w-56">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-theme2" />
          <input
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search items…"
            className="w-full pl-8 pr-3 py-2 rounded-xl border bg-card text-theme text-sm placeholder:text-theme2 outline-none focus:ring-2 focus:ring-[var(--accent)]/30 transition"
            style={{ borderColor: 'var(--border)' }}
          />
        </div>
        <div className="flex items-center rounded-xl border p-0.5 flex-shrink-0" style={{ borderColor: 'var(--border)' }}>
          <button
            onClick={() => onViewModeChange('list')}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition"
            style={{
              background: viewMode === 'list' ? 'var(--accentlt)' : 'transparent',
              color: viewMode === 'list' ? 'var(--accent)' : 'var(--text2)',
            }}
            title="List view"
          >
            <List size={15} />
          </button>
          <button
            onClick={() => onViewModeChange('grid')}
            className="w-8 h-8 rounded-lg flex items-center justify-center transition"
            style={{
              background: viewMode === 'grid' ? 'var(--accentlt)' : 'transparent',
              color: viewMode === 'grid' ? 'var(--accent)' : 'var(--text2)',
            }}
            title="Grid view"
          >
            <LayoutGrid size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
