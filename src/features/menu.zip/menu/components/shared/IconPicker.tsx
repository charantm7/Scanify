'use client';

// src/features/menu/components/shared/IconPicker.tsx
//
// Emoji icon picker for category headers — click-outside-to-close popover.

import { useEffect, useRef, useState } from 'react';
import { CATEGORY_ICON_PRESETS } from '../../constants';

export function IconPicker({ value, onChange }: { value: string | null; onChange: (icon: string) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-8 h-8 rounded-lg flex items-center justify-center text-base hover:bg-theme3 transition flex-shrink-0"
        style={{ background: 'var(--accentlt)' }}
        title="Choose icon"
      >
        {value || '🍽️'}
      </button>
      {open && (
        <div
          className="absolute z-20 top-10 left-0 grid grid-cols-5 gap-1 p-2 rounded-xl border shadow-lg"
          style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
        >
          {CATEGORY_ICON_PRESETS.map((icon) => (
            <button
              key={icon}
              type="button"
              onClick={() => {
                onChange(icon);
                setOpen(false);
              }}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-base hover:bg-theme3 transition"
            >
              {icon}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
