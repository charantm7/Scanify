// src/features/menu/components/shared/TagBadge.tsx

import { TAG_META } from '../../constants';
import type { ItemTag } from '../../types';

export function TagBadge({ tag }: { tag: ItemTag }) {
  const meta = TAG_META[tag];
  return (
    <span
      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold"
      style={{ background: 'var(--accentlt)', color: 'var(--accent)' }}
    >
      <span>{meta.emoji}</span>
      {meta.label}
    </span>
  );
}
