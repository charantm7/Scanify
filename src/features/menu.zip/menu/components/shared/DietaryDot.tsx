// src/features/menu/components/shared/DietaryDot.tsx
//
// The square-outline-with-dot symbol standard on Indian restaurant menus.

import { DIETARY_META } from '../../constants';
import type { DietaryType } from '../../types';

export function DietaryDot({ type, size = 12 }: { type: DietaryType; size?: number }) {
  const meta = DIETARY_META[type];
  return (
    <span
      title={meta.label}
      className="inline-flex items-center justify-center rounded-sm border flex-shrink-0"
      style={{ width: size, height: size, borderColor: meta.ring, padding: 1 }}
    >
      <span className="block rounded-full" style={{ width: '60%', height: '60%', background: meta.dot }} />
    </span>
  );
}
