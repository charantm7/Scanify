'use client';

// src/features/menu/components/ItemForm.tsx
//
// Advanced item form: base price + optional size/portion variants,
// dietary type, merchandising tags, image, availability.

import { ChefHat, DollarSign, Image as ImageIcon, Plus, X as XIcon } from 'lucide-react';
import { Input, Textarea, Toggle, Button } from '../../../components/shared/ui';
import { DIETARY_META, TAG_META, MAX_VARIANTS_PER_ITEM } from '../constants';
import { useItemForm } from '../hooks/useItemForm';
import type { MenuItem, DietaryType, ItemTag, ItemFormValues } from '../types';

interface ItemFormProps {
  initial?: MenuItem | null;
  onSubmit: (values: ItemFormValues) => void;
  loading?: boolean;
}

export function ItemForm({ initial = null, onSubmit, loading }: ItemFormProps) {
  const { form, errors, setField, toggleTag, addVariant, updateVariant, removeVariant, validate } =
    useItemForm(initial);

  function handleSubmit() {
    if (!validate()) return;
    onSubmit(form);
  }

  return (
    <div className="space-y-5">
      {/* Basic info */}
      <div className="space-y-4">
        <Input
          label="Item Name *"
          placeholder="e.g. Butter Chicken"
          value={form.name}
          onChange={(e) => setField('name', e.target.value)}
          error={errors.name}
          icon={ChefHat}
        />
        <Textarea
          label="Description"
          placeholder="Brief description of the dish…"
          value={form.description}
          onChange={(e) => setField('description', e.target.value)}
          rows={2}
        />
      </div>

      {/* Pricing */}
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-3">
          <Input
            label="Base Price (₹) *"
            placeholder="0.00"
            type="number"
            min="0"
            step="0.01"
            value={form.price}
            onChange={(e) => setField('price', e.target.value)}
            error={errors.price}
            icon={DollarSign}
          />
          <Input
            label="Image URL"
            placeholder="https://..."
            value={form.image_url}
            onChange={(e) => setField('image_url', e.target.value)}
            icon={ImageIcon}
          />
        </div>

        <div className="pt-1">
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-theme2">Size / portion variants (optional)</label>
            {form.variants.length < MAX_VARIANTS_PER_ITEM && (
              <button
                type="button"
                onClick={addVariant}
                className="text-xs font-semibold flex items-center gap-1"
                style={{ color: 'var(--accent)' }}
              >
                <Plus size={12} /> Add variant
              </button>
            )}
          </div>
          {form.variants.length > 0 && (
            <div className="space-y-2">
              {form.variants.map((variant) => (
                <div key={variant.id} className="flex items-center gap-2">
                  <input
                    placeholder="Label (e.g. Half)"
                    value={variant.label}
                    onChange={(e) => updateVariant(variant.id, { label: e.target.value })}
                    className="flex-1 px-3 py-2 rounded-lg border bg-card text-theme text-sm outline-none"
                    style={{ borderColor: 'var(--border)' }}
                  />
                  <input
                    placeholder="Price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={variant.price || ''}
                    onChange={(e) => updateVariant(variant.id, { price: Number(e.target.value) })}
                    className="w-24 px-3 py-2 rounded-lg border bg-card text-theme text-sm outline-none"
                    style={{ borderColor: 'var(--border)' }}
                  />
                  <button
                    type="button"
                    onClick={() => removeVariant(variant.id)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 transition flex-shrink-0"
                  >
                    <XIcon size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
          {errors.variants && <p className="text-xs text-red-500 mt-1">{errors.variants}</p>}
        </div>
      </div>

      {/* Classification */}
      <div className="space-y-3">
        <div>
          <label className="text-xs font-semibold text-theme2 block mb-1.5">Dietary type</label>
          <div className="flex gap-2 flex-wrap">
            {(Object.keys(DIETARY_META) as DietaryType[]).map((key) => {
              const meta = DIETARY_META[key];
              const active = form.dietary_type === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setField('dietary_type', active ? '' : key)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition"
                  style={{
                    borderColor: active ? meta.ring : 'var(--border)',
                    background: active ? 'var(--accentlt)' : 'transparent',
                    color: active ? meta.ring : 'var(--text2)',
                  }}
                >
                  <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: meta.dot }} />
                  {meta.label}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-theme2 block mb-1.5">Tags</label>
          <div className="flex gap-2 flex-wrap">
            {(Object.keys(TAG_META) as ItemTag[]).map((key) => {
              const meta = TAG_META[key];
              const active = form.tags.includes(key);
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => toggleTag(key)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition"
                  style={{
                    borderColor: active ? 'var(--accent)' : 'var(--border)',
                    background: active ? 'var(--accentlt)' : 'transparent',
                    color: active ? 'var(--accent)' : 'var(--text2)',
                  }}
                >
                  <span>{meta.emoji}</span> {meta.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <Toggle checked={form.is_available} onChange={(v) => setField('is_available', v)} label="Available for ordering" />

      <div className="pt-2 flex justify-end gap-3">
        <Button variant="primary" loading={loading} onClick={handleSubmit}>
          {initial?.id ? 'Save Changes' : 'Add Item'}
        </Button>
      </div>
    </div>
  );
}
