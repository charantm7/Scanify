import LegalLayout from "../../../components/legal/LegalLayout";
import LegalRender from "../../../components/legal/LegalRender";
import { getLegalDoc } from "../../../lib/legal/legalhelper";

export const metadata = {
    title: "Cookie Policy | Scanify",
    description: "Read the Cookie Policy for using the Scanify platform.",
};

export default function TermsPage() {
    const content = getLegalDoc("cookies");

    return (

        <LegalLayout title="Cookie Policy" lastUpdated="April 26, 2026">
            <LegalRender content={content} />
        </LegalLayout>
    );
}