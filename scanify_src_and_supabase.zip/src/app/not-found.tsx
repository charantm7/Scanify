"use client";

export default function NotFound() {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen">
            <h1 className="text-5xl font-bold">404</h1>
            <p className="mt-4 text-lg">Page not found</p>
        </div>
    );
}