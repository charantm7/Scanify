import "../style/globals.css";
import { AppProvider } from "../../context/AppContext";
export const metadata = {
    title: "Scanify | Login",
    description: "Replace printed menus with a smart digital solution. Customers scan a QR code and instantly browse your full menu — contactless, fast, and always up to date.",
};

export default async function AuthLayout({ children }) {

    return (
        <>
            <AppProvider>
                {children}
            </AppProvider>
        </>

    );
}