// app/auth-callback/route.js
import { createClient } from '../../../lib/supabase/server';
import { NextResponse } from 'next/server';
import { createUserProfile, getUserProfile, getUserProfileWithOnboarding } from '../../../lib/queries/user';
import { UserInsert, UserRow } from '../../../types/supabase';

export async function GET(request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const type = searchParams.get('type');

  if (!code) {
    console.log("code: ", code)
    return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
  }

  const supabase = await createClient();
  const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);

  if (exchangeError) {
    return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
  }

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
  }

  if (type === 'recovery') {
    const response = NextResponse.redirect(`${origin}/reset-password`);

    response.cookies.set('recovery_flow', 'true', {
      httpOnly: true,
      maxAge: 60 * 5
    })

    return response;
  }

  const profile = await getUserProfileWithOnboarding(supabase, user?.id)

  if (!profile) {
    const payload: UserInsert = {
      id: user.id,
      onboarding_complete: false,
      email: user.email,
      is_verified: true,
    }
    await createUserProfile(supabase, payload);

    return NextResponse.redirect(`${origin}/onboarding`);
  }

  return NextResponse.redirect(
    profile.onboarding_complete ? `${origin}/console` : `${origin}/onboarding`
  );
}